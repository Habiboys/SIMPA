export enum Kategori {
  INDOOR = 'indoor',
  OUTDOOR = 'outdoor',
}
