import { Controller } from '@nestjs/common';

@Controller('ac')
export class AcController {}
