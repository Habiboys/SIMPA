export enum Keadaan {
    SESUDAH = 'sesudah',
    SEBELUM = 'sebelum',
  }
  