export enum Role {
  ADMIN = 'admin',
  LAPANGAN = 'lapangan',
}
